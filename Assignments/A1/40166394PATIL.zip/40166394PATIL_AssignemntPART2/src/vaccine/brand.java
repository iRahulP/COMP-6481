package vaccine;

/**
 * 
 * @author rahul
 * Assignment (1)
 * Rahul PATIL
 * Written by: (Rahul PATIL : 40166394)
 * vaccine class
 *
 * enum of vaccine brands : represents static objects
 * 
 */
public enum brand {
	Pfizer,
	BioNTech,
	Moderna,
	Oxford,
	Johnson,
	Novavax,
	AstraZeneca,
	Sputnik
};
